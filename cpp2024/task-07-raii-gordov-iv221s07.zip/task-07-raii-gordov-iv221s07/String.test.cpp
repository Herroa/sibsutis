#include "String.hpp"
#include <gtest/gtest.h>

TEST(StringTest, DefaultConstructor) {
  const String s;
  EXPECT_EQ(s.size(), 0);
  EXPECT_STREQ(s.c_str(), "");
}

TEST(StringTest, CStrConstructor) {
  const String s("test");
  EXPECT_EQ(s.size(), 4);
  EXPECT_STREQ(s.c_str(), "test");
}

TEST(StringTest, CopyConstructor) {
  const String s1("test");
  const String s2(s1);
  EXPECT_EQ(s2.size(), 4);
  EXPECT_STREQ(s2.c_str(), "test");
}

TEST(StringTest, MoveConstructor) {
  String s1("test");
  const String s2(std::move(s1));
  EXPECT_EQ(s2.size(), 4);
  EXPECT_STREQ(s2.c_str(), "test");
  EXPECT_EQ(s1.c_str(), nullptr);
}

TEST(StringTest, AtMethod) {
  const String s("test");
  EXPECT_EQ(s.at(0), 't');
  EXPECT_EQ(s.at(2), 's');
  EXPECT_THROW(s.at(4), std::out_of_range);
}

TEST(StringTest, AssignmentOperatorCopy) {
  const String s1("test");
  String s2;
  s2 = s1;
  EXPECT_EQ(s2.size(), 4);
  EXPECT_STREQ(s2.c_str(), "test");
}

TEST(StringTest, AssignmentOperatorMove) {
  String s1("test");
  String s2;
  s2 = std::move(s1);
  EXPECT_EQ(s2.size(), 4);
  EXPECT_STREQ(s2.c_str(), "test");
  EXPECT_EQ(s1.c_str(), nullptr);
}

TEST(StringTest, EqualityOperators) {
  const String s1("test");
  const String s2("test");
  const String s3("don");
  EXPECT_TRUE(s1 == s2);
  EXPECT_FALSE(s1 == s3);
  EXPECT_TRUE(s1 != s3);
}
