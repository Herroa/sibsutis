#include <cstddef>

class String {
 private:
  std::size_t size_;
  char* data_;

 public:
  String();
  String(const String& other);
  String(String&& other);
  explicit String(const char* cstr);
  ~String();
  String& operator=(const String& other);
  String& operator=(String&& other);
  const char* c_str() const;
  char& at(std::size_t idx);
  const char& at(std::size_t idx) const;
  std::size_t size() const;

  bool operator==(const String& other) const;
  bool operator!=(const String& other) const;
};