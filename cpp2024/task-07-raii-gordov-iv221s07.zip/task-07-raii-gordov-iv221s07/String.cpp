#include "String.hpp"
#include <cstring>
#include <stdexcept>

String::String() : size_(0), data_(new char[1]{'\0'}) {}

String::String(const String& other)
    : size_(other.size_), data_(new char[other.size_ + 1]) {
  std::memcpy(data_, other.data_, size_ + 1);
}

String::String(String&& other) : size_(other.size_), data_(other.data_) {
  other.size_ = 0;
  other.data_ = nullptr;
}

String::String(const char* cstr)
    : size_(std::strlen(cstr)), data_(new char[size_ + 1]) {
  std::memcpy(data_, cstr, size_ + 1);
}

String::~String() {
  delete[] data_;
}

String& String::operator=(const String& other) {
  if (this == &other)
    return *this;

  delete[] data_;
  size_ = other.size_;
  data_ = new char[size_ + 1];
  std::memcpy(data_, other.data_, size_ + 1);

  return *this;
}

String& String::operator=(String&& other) {
  if (this == &other)
    return *this;

  delete[] data_;
  size_ = other.size_;
  data_ = other.data_;

  other.size_ = 0;
  other.data_ = nullptr;

  return *this;
}

const char* String::c_str() const {
  return data_;
}

std::size_t String::size() const {
  return size_;
}

char& String::at(std::size_t idx) {
  if (idx >= size_)
    throw std::out_of_range("out of range");
  return data_[idx];
}

const char& String::at(std::size_t idx) const {
  if (idx >= size_)
    throw std::out_of_range("out of range");
  return data_[idx];
}

bool String::operator==(const String& other) const {
  return size_ == other.size_ && std::strcmp(data_, other.data_) == 0;
}

bool String::operator!=(const String& other) const {
  return !(*this == other);
}